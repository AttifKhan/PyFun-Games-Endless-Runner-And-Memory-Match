import pygame
import sys
import random

# Initialize Pygame and set up the game window
pygame.init()

WIDTH, HEIGHT = 800, 600
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Endless Runner")

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Define player properties
PLAYER_WIDTH, PLAYER_HEIGHT = 50, 50

# Define obstacle properties
OBSTACLE_WIDTH, OBSTACLE_HEIGHT = 50, 50
OBSTACLE_SPEED = 5

# Define class for the player
class Player:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH // 2 - PLAYER_WIDTH // 2, HEIGHT - PLAYER_HEIGHT - 10, PLAYER_WIDTH, PLAYER_HEIGHT)

    def move(self, direction):
        if direction == "LEFT" and self.rect.left > 0:
            self.rect.x -= 5
        elif direction == "RIGHT" and self.rect.right < WIDTH:
            self.rect.x += 5

    def draw(self):
        pygame.draw.rect(win, WHITE, self.rect)

# Define class for obstacles
class Obstacle:
    def __init__(self, x):
        self.rect = pygame.Rect(x, -OBSTACLE_HEIGHT, OBSTACLE_WIDTH, OBSTACLE_HEIGHT)

    def move(self):
        self.rect.y += OBSTACLE_SPEED

    def draw(self):
        pygame.draw.rect(win, RED, self.rect)

# Set up the game loop
def main():
    player = Player()
    obstacles = []

    clock = pygame.time.Clock()

    # Variables for time display and failed attempts
    start_time = pygame.time.get_ticks()
    failed_attempts = 0
    show_fail_message = False
    fail_message_start_time = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player.move("LEFT")
        if keys[pygame.K_RIGHT]:
            player.move("RIGHT")

        # Generate obstacles
        if random.randint(0, 100) < 2:
            x = random.randint(0, WIDTH - OBSTACLE_WIDTH)
            obstacles.append(Obstacle(x))

        # Update player and obstacles
        for obstacle in obstacles:
            obstacle.move()

        # Remove obstacles that go off the screen
        obstacles = [obstacle for obstacle in obstacles if obstacle.rect.y < HEIGHT]

        # Check for collision with obstacles
        for obstacle in obstacles:
            if player.rect.colliderect(obstacle.rect):
                failed_attempts += 1
                if failed_attempts >= 5:
                    show_fail_message = True
                    fail_message_start_time = pygame.time.get_ticks()

                pygame.quit()
                sys.exit()

        win.fill(BLACK)

        # Draw player and obstacles
        player.draw()
        for obstacle in obstacles:
            obstacle.draw()

        # Calculate and display time
        current_time = pygame.time.get_ticks()
        elapsed_time = (current_time - start_time) // 1000  # Convert to seconds
        font = pygame.font.Font(None, 36)
        time_text = font.render(f"Time: {elapsed_time}s", True, WHITE)
        win.blit(time_text, (10, 10))  # Display time at top-left corner

        # Display "Better luck next time" message for 30 seconds
        if show_fail_message:
            current_fail_time = pygame.time.get_ticks()
            elapsed_fail_time = (current_fail_time - fail_message_start_time) // 1000
            if elapsed_fail_time < 30:
                fail_font = pygame.font.Font(None, 72)
                fail_message = fail_font.render("Better luck next time", True, WHITE)
                fail_message_rect = fail_message.get_rect(center=(WIDTH // 2, HEIGHT // 2))
                win.blit(fail_message, fail_message_rect)
            else:
                show_fail_message = False

        pygame.display.update()
        clock.tick(60)

if __name__ == "__main__":
    main()
