import pygame
import sys
import random

# Initialize Pygame and set up the game window
pygame.init()

WIDTH, HEIGHT = 800, 600
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Memory Game")

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Define card properties
CARD_WIDTH, CARD_HEIGHT = 100, 100
GAP = 20

# Define class for cards
class Card:
    def __init__(self, x, y, value):
        self.rect = pygame.Rect(x, y, CARD_WIDTH, CARD_HEIGHT)
        self.value = value
        self.is_flipped = False
        self.is_matched = False

    def draw(self):
        if self.is_matched:
            pygame.draw.rect(win, RED, self.rect)  # Change color of matched cards
        elif self.is_flipped:
            pygame.draw.rect(win, WHITE, self.rect)
            pygame.draw.rect(win, BLACK, self.rect, 2)
            font = pygame.font.Font(None, 36)
            text = font.render(str(self.value), True, BLACK)
            text_rect = text.get_rect(center=self.rect.center)
            win.blit(text, text_rect)
        else:
            pygame.draw.rect(win, GREEN, self.rect)
            pygame.draw.rect(win, BLACK, self.rect, 2)

# New game properties for increased complexity
ROWS, COLS = 4, 5
FLIP_DELAY = 300
TIMER_DURATION = 60  # 60 seconds for the timer

# Create pairs of cards with the same value
values = list(range(1, (ROWS * COLS) // 2 + 1)) * 2
random.shuffle(values)

# Shuffle the cards and make sure pairs with the same value are not side by side
temp_cards = [Card(0, 0, value) for value in values]
random.shuffle(temp_cards)
random.shuffle(temp_cards)

# Assign the shuffled cards back to the main cards list
cards = []
x, y = GAP, GAP
for card in temp_cards:
    card.rect.topleft = (x, y)
    cards.append(card)
    x += CARD_WIDTH + GAP
    if x >= WIDTH - GAP:
        x = GAP
        y += CARD_HEIGHT + GAP

# Set up the game loop
def main():
    flipped_cards = []
    game_over = False
    start_time = pygame.time.get_ticks()  # Get the start time for the timer

    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                for card in cards:
                    if card.rect.collidepoint(pos) and not card.is_flipped and not card.is_matched:
                        card.is_flipped = True
                        flipped_cards.append(card)

                if len(flipped_cards) == 2:
                    pygame.time.wait(FLIP_DELAY)  # Show the flipped cards for a brief moment

                    if flipped_cards[0].value == flipped_cards[1].value:
                        for card in flipped_cards:
                            card.is_matched = True
                    else:
                        for card in flipped_cards:
                            card.is_flipped = False

                    flipped_cards.clear()

        win.fill(BLACK)

        # Draw cards and other elements
        for card in cards:
            card.draw()

        pygame.display.update()

        # Check for game over condition
        if all(card.is_matched for card in cards):
            game_over = True

        # Check for timer expiration
        current_time = pygame.time.get_ticks()
        elapsed_time = (current_time - start_time) // 1000  # Convert to seconds
        if elapsed_time >= TIMER_DURATION:
            game_over = True

    # Game over screen
    font = pygame.font.Font(None, 72)
    if elapsed_time >= TIMER_DURATION:
        text = font.render("Time's up! You lose!", True, WHITE)
    else:
        text = font.render("Congratulations! You won!", True, WHITE)

    text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    win.blit(text, text_rect)
    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

if __name__ == "__main__":
    main()
