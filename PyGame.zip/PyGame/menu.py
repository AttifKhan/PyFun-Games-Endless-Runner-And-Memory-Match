import pygame
import sys
import endless_runner
import memory_game

# Initialize Pygame and set up the game window
pygame.init()

WIDTH, HEIGHT = 800, 600
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Game Menu")

# Create a function for the main menu
def main_menu():
    global win  # Define win as a global variable
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if endless_runner_option_rect.collidepoint(pos):
                    endless_runner.main()  # Launch the Endless Runner game
                elif memory_game_option_rect.collidepoint(pos):
                    memory_game.main()  # Launch the Memory Game

        # Draw menu options and other elements
        win.fill((0, 0, 0))  # Fill the background with black color

        # Define menu option texts
        font = pygame.font.Font(None, 36)
        endless_runner_text = font.render("Endless Runner", True, (255, 255, 255))
        memory_game_text = font.render("Memory Game", True, (255, 255, 255))

        # Define menu option rectangles for mouse click detection
        endless_runner_option_rect = endless_runner_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
        memory_game_option_rect = memory_game_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50))

        # Draw menu options on the screen
        win.blit(endless_runner_text, endless_runner_option_rect)
        win.blit(memory_game_text, memory_game_option_rect)

        pygame.display.update()

if __name__ == "__main__":
    main_menu()
